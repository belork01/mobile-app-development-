# Basic-Banking-App
A native Banking Application built using Java and SQLite as a part of the Graduate Rotational Internship Program (GRIP) at The Sparks Foundation
